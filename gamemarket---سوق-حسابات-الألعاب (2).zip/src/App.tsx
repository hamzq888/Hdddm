import React, { useState, useMemo } from 'react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { useCollection } from 'react-firebase-hooks/firestore';
import { collection, query, orderBy, limit, where } from 'firebase/firestore';
import { AnimatePresence, motion } from 'motion/react';
import { Filter, ShoppingBag, Loader2, Gamepad2, CreditCard, ChevronRight, Trophy } from 'lucide-react';

import { auth, db } from './lib/firebase';
import { GameAccount, GameCategory } from './types';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import AccountCard from './components/AccountCard';
import CreateListing from './components/CreateListing';

const CATEGORIES: GameCategory[] = ['Valorant', 'League of Legends', 'Steam', 'Battle.net', 'Epic Games', 'Other'];

export default function App() {
  const [user] = useAuthState(auth);
  const [showCreate, setShowCreate] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<GameCategory | 'All'>('All');
  const [selectedAccount, setSelectedAccount] = useState<GameAccount | null>(null);

  // Firestore fetch
  const accountsQuery = useMemo(() => {
    let q = query(collection(db, 'accounts'), orderBy('createdAt', 'desc'), limit(20));
    if (activeCategory !== 'All') {
      q = query(collection(db, 'accounts'), where('game', '==', activeCategory), orderBy('createdAt', 'desc'), limit(20));
    }
    return q;
  }, [activeCategory]);

  const [snapshot, loading, error] = useCollection(accountsQuery);

  const accounts = useMemo(() => {
    if (!snapshot) return [];
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as GameAccount[];
  }, [snapshot]);

  const filteredAccounts = useMemo(() => {
    return accounts.filter(acc => 
      acc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      acc.game.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [accounts, searchQuery]);

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-indigo-500/30">
      <Navbar onShowCreate={() => setShowCreate(true)} onSearch={setSearchQuery} />
      
      <main>
        <Hero />

        {/* Categories Bar */}
        <div className="max-w-7xl mx-auto px-6 mb-12">
           <div className="flex items-center gap-4 overflow-x-auto pb-4 scrollbar-hide no-scrollbar" dir="rtl">
              <button
                onClick={() => setActiveCategory('All')}
                className={`flex-shrink-0 px-6 py-3 rounded-full font-bold transition-all border ${activeCategory === 'All' ? 'bg-indigo-600 border-indigo-500 text-white shadow-[0_0_20px_rgba(79,70,229,0.4)]' : 'bg-gray-900 border-gray-800 text-gray-400 hover:border-gray-700'}`}
              >
                الكل
              </button>
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`flex-shrink-0 px-6 py-3 rounded-full font-bold transition-all border ${activeCategory === cat ? 'bg-indigo-600 border-indigo-500 text-white shadow-[0_0_20px_rgba(79,70,229,0.4)]' : 'bg-gray-900 border-gray-800 text-gray-400 hover:border-gray-700'}`}
                >
                  {cat}
                </button>
              ))}
           </div>
        </div>

        {/* Main List */}
        <section className="max-w-7xl mx-auto px-6 pb-32">
          <div className="flex items-center justify-between mb-8" dir="rtl">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-500/10 rounded-lg">
                <Filter className="w-6 h-6 text-indigo-500" />
              </div>
              <h2 className="text-3xl font-black tracking-tighter">العروض المتاحة</h2>
            </div>
            <div className="text-sm text-gray-500 font-medium">
              تم العثور على {filteredAccounts.length} حساب
            </div>
          </div>

          {loading ? (
            <div className="flex flex-col items-center justify-center py-32 space-y-4">
              <Loader2 className="w-12 h-12 text-indigo-500 animate-spin" />
              <p className="text-gray-400 font-medium italic">جاري تحميل أفضل العروض...</p>
            </div>
          ) : error ? (
            <div className="text-center py-20 bg-red-500/5 border border-red-500/20 rounded-3xl">
              <p className="text-red-400">خطأ في تحميل البيانات. يرجى التحقق من إعدادات فايربيس.</p>
            </div>
          ) : filteredAccounts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredAccounts.map(acc => (
                <AccountCard 
                  key={acc.id} 
                  account={acc} 
                  onView={(a) => setSelectedAccount(a)} 
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-32 bg-gray-900/30 rounded-3xl border border-dashed border-gray-800">
               <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Gamepad2 className="w-8 h-8 text-gray-600" />
               </div>
               <p className="text-gray-500 font-medium text-lg">لم يتم العثور على أي حسابات في هذا القسم حالياً.</p>
            </div>
          )}
        </section>
      </main>

      {/* Account Detail Modal */}
      <AnimatePresence>
        {selectedAccount && (
          <AccountDetailView 
            account={selectedAccount} 
            onClose={() => setSelectedAccount(null)} 
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCreate && (
          <CreateListing 
            onClose={() => setShowCreate(false)} 
            onSuccess={() => {
              setShowCreate(false);
              // Refresh or show toast
            }} 
          />
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="border-t border-gray-900 bg-black py-20 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-10" dir="rtl">
          <div className="space-y-4 text-center md:text-right">
            <span className="text-2xl font-black text-white">GAME<span className="text-indigo-500">MARKET</span></span>
            <p className="text-gray-500 max-w-sm">
              المنصة رقم #1 لببيع وشراء حسابات الألعاب في العالم العربي. سرعة، أمان، وموثوقية بالكامل.
            </p>
          </div>
          <div className="flex gap-8">
            <a href="#" className="text-gray-400 hover:text-white transition-colors">اتصل بنا</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">شروط الخدمة</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">سياسة الخصوصية</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

function AccountDetailView({ account, onClose }: { account: GameAccount; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md"
    >
      <motion.div
        initial={{ scale: 0.9, y: 50 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-gray-900 border border-gray-800 w-full max-w-5xl h-full max-h-[90vh] rounded-[3rem] overflow-hidden flex flex-col md:flex-row"
        dir="rtl"
      >
        <div className="w-full md:w-1/2 bg-black relative">
          <img
            src={account.images[0]}
            alt={account.title}
            className="w-full h-full object-contain"
            referrerPolicy="no-referrer"
          />
          <button onClick={onClose} className="absolute top-6 right-6 p-3 bg-black/50 hover:bg-black rounded-full text-white backdrop-blur transition-all">
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
        <div className="flex-1 p-10 overflow-y-auto space-y-8">
           <div className="space-y-4">
             <div className="flex items-center gap-3">
               <span className="px-4 py-1 bg-indigo-500/10 text-indigo-500 rounded-full text-xs font-black uppercase tracking-widest border border-indigo-500/20">
                 {account.game}
               </span>
               {account.status !== 'available' && (
                  <span className="px-4 py-1 bg-red-500/10 text-red-500 rounded-full text-xs font-black uppercase tracking-widest border border-red-500/20">
                    مباع
                  </span>
               )}
             </div>
             <h2 className="text-4xl font-black text-white leading-tight">{account.title}</h2>
             <div className="flex items-center gap-4 text-gray-400">
               <div className="flex items-center gap-1.5 bg-gray-800/50 px-4 py-2 rounded-2xl">
                 <Trophy className="w-5 h-5 text-yellow-500" />
                 <span className="font-bold">{account.rank}</span>
               </div>
               <div className="flex items-center gap-1.5 bg-gray-800/50 px-4 py-2 rounded-2xl">
                 <Gamepad2 className="w-5 h-5 text-indigo-500" />
                 <span className="font-bold">مستوى {account.level}</span>
               </div>
             </div>
           </div>

           <div className="p-8 bg-gray-800/30 border border-gray-800 rounded-3xl space-y-4">
             <div className="text-gray-400 font-bold mb-2">الوصف:</div>
             <p className="text-gray-300 leading-relaxed text-lg italic">
               "{account.description || 'لا يوجد وصف متاح لهذا الحساب.'}"
             </p>
           </div>

           <div className="flex flex-col sm:flex-row items-center gap-6 pt-4">
             <div className="text-5xl font-black text-white flex items-baseline gap-2">
               {account.price}
               <span className="text-xl font-medium text-indigo-400">دولار</span>
             </div>
             <button
               disabled={account.status !== 'available'}
               className="flex-1 w-full flex items-center justify-center gap-3 py-5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-2xl rounded-3xl transition-all shadow-[0_10px_30px_rgba(79,70,229,0.3)] disabled:opacity-50 disabled:cursor-not-allowed group"
             >
               <CreditCard className="w-7 h-7 group-hover:scale-110 transition-transform" />
               <span>شراء الآن</span>
             </button>
           </div>

           <div className="flex items-center gap-3 pt-6 border-t border-gray-800">
             <div className="w-14 h-14 bg-indigo-600/20 rounded-2xl flex items-center justify-center border border-indigo-500/20">
               <ShoppingBag className="w-8 h-8 text-indigo-500" />
             </div>
             <div>
               <div className="text-white font-bold text-lg">بواسطة {account.sellerName}</div>
               <div className="text-sm text-gray-500">عضو موثوق منذ ٢٠٢٤</div>
             </div>
           </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
