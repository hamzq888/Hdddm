import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export type GameCategory = 'Valorant' | 'League of Legends' | 'Steam' | 'Battle.net' | 'Epic Games' | 'Other';

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  rating: number;
  createdAt: any;
}

export interface GameAccount {
  id: string;
  title: string;
  game: GameCategory;
  price: number;
  description: string;
  sellerId: string;
  sellerName: string;
  status: 'available' | 'sold' | 'pending';
  level: number;
  rank: string;
  images: string[];
  createdAt: any;
  updatedAt: any;
}

export interface Order {
  id: string;
  buyerId: string;
  sellerId: string;
  accountId: string;
  amount: number;
  status: 'pending' | 'completed' | 'cancelled';
  createdAt: any;
  updatedAt: any;
}
