import React from 'react';
import { motion } from 'motion/react';
import { Shield, Zap, Trophy, Coins } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 px-6 overflow-hidden">
      {/* Background Glows */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-[120px]" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-[120px]" />

      <div className="max-w-7xl mx-auto relative">
        <div className="text-center space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter leading-tight drop-shadow-2xl">
              سوق <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-purple-500">حسابات الألعاب</span> الأفضل <br />
              بيع وشراء بأمان تام
            </h1>
            <p className="mt-6 text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">
              انضم إلى آلاف اللاعبين في أكبر منصة عربية لتداول حسابات الألعاب. حسابات موثقة، تسليم فوري، ودعم فني على مدار الساعة.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="flex flex-wrap justify-center gap-4 pt-4"
          >
            <div className="bg-gray-900/50 backdrop-blur border border-white/5 px-8 py-4 rounded-2xl flex items-center gap-3">
              <Shield className="w-6 h-6 text-green-500" />
              <div className="text-right">
                <div className="text-white font-bold">حماية المشتري</div>
                <div className="text-xs text-gray-500 italic">ضمان 100%</div>
              </div>
            </div>
            <div className="bg-gray-900/50 backdrop-blur border border-white/5 px-8 py-4 rounded-2xl flex items-center gap-3">
              <Zap className="w-6 h-6 text-yellow-500" />
              <div className="text-right">
                <div className="text-white font-bold">تسليم فوري</div>
                <div className="text-xs text-gray-500 italic">بضغط زر واحدة</div>
              </div>
            </div>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 max-w-4xl mx-auto">
             {[
               { icon: Trophy, label: 'رتب عالية', color: 'text-indigo-500' },
               { icon: Coins, label: 'أسعار مناسبة', color: 'text-emerald-500' },
               { icon: Shield, label: 'بائعين موثقين', color: 'text-blue-500' },
               { icon: Zap, label: 'أحدث العروض', color: 'text-purple-500' }
             ].map((item, idx) => (
                <motion.div
                  key={idx}
                  whileHover={{ y: -5 }}
                  className="bg-gray-900/40 border border-gray-800 p-6 rounded-3xl text-center group cursor-default transition-all hover:border-indigo-500/50"
                >
                  <item.icon className={`w-10 h-10 mx-auto mb-3 ${item.color} group-hover:scale-110 transition-transform`} />
                  <div className="text-white font-bold">{item.label}</div>
                </motion.div>
             ))}
          </div>
        </div>
      </div>
    </section>
  );
}
