import React from 'react';
import { motion } from 'motion/react';
import { ExternalLink, Tag, Trophy, User } from 'lucide-react';
import { GameAccount } from '../types';

interface AccountCardProps {
  account: GameAccount;
  onView: (account: GameAccount) => void;
}

export default function AccountCard({ account, onView }: AccountCardProps) {
  const getGameColor = (game: string) => {
    switch (game) {
      case 'Valorant': return 'text-red-500 border-red-500/20 bg-red-500/10';
      case 'League of Legends': return 'text-blue-500 border-blue-500/20 bg-blue-500/10';
      default: return 'text-indigo-500 border-indigo-500/20 bg-indigo-500/10';
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -8 }}
      className="bg-gray-900 border border-gray-800 rounded-3xl overflow-hidden group cursor-pointer transition-all hover:border-indigo-500/40 shadow-xl"
      onClick={() => onView(account)}
    >
      <div className="relative aspect-video overflow-hidden">
        <img
          src={account.images[0] || 'https://picsum.photos/seed/game/600/400'}
          alt={account.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-3 right-3">
          <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border ${getGameColor(account.game)}`}>
            {account.game}
          </span>
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-gray-900 to-transparent">
          <div className="text-xl font-bold text-white truncate">{account.title}</div>
        </div>
      </div>

      <div className="p-6 space-y-4" dir="rtl">
        <div className="flex items-center justify-between">
           <div className="flex items-center gap-2 text-indigo-400 font-black text-2xl">
             <span>{account.price}</span>
             <span className="text-sm font-medium">دولار</span>
           </div>
           <div className="flex items-center gap-1.5 text-gray-400 text-sm">
             <Trophy className="w-4 h-4" />
             <span>{account.rank}</span>
           </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-gray-800/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center">
              <User className="w-4 h-4 text-gray-400" />
            </div>
            <span className="text-sm text-gray-400">{account.sellerName}</span>
          </div>
          <button className="text-indigo-500 group-hover:bg-indigo-500 group-hover:text-white p-2 rounded-xl transition-all">
            <ExternalLink className="w-5 h-5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
