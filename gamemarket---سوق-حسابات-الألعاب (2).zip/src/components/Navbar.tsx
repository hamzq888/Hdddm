import React from 'react';
import { LayoutGrid, ShoppingCart, User, LogIn, PlusCircle, Search } from 'lucide-react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, signInWithGoogle } from '../lib/firebase';
import { cn } from '../types';

interface NavbarProps {
  onShowCreate: () => void;
  onSearch: (query: string) => void;
}

export default function Navbar({ onShowCreate, onSearch }: NavbarProps) {
  const [user] = useAuthState(auth);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-indigo-500/20 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(79,70,229,0.5)]">
            <LayoutGrid className="text-white w-6 h-6" />
          </div>
          <span className="text-2xl font-bold text-white tracking-tighter hidden sm:block">
            GAME<span className="text-indigo-500">MARKET</span>
          </span>
        </div>

        <div className="flex-1 max-w-xl relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-indigo-500 transition-colors" />
          <input
            type="text"
            placeholder="ابحث عن حسابك المفضل... (فالورانت، لول، ستيم)"
            onChange={(e) => onSearch(e.target.value)}
            className="w-full bg-gray-900 border border-gray-800 text-white pl-10 pr-4 py-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all text-right"
            dir="rtl"
          />
        </div>

        <div className="flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-3">
              <button
                onClick={onShowCreate}
                className="hidden md:flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl transition-all shadow-lg active:scale-95"
              >
                <PlusCircle className="w-5 h-5" />
                <span>بيع حساب</span>
              </button>
              <div className="flex items-center gap-2 bg-gray-900 border border-gray-800 p-1.5 rounded-full">
                <img
                  src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`}
                  alt="Avatar"
                  className="w-8 h-8 rounded-full bg-indigo-500"
                  referrerPolicy="no-referrer"
                />
                <span className="hidden lg:block text-sm font-medium text-gray-300 pr-2 truncate max-w-[100px]">
                  {user.displayName}
                </span>
              </div>
            </div>
          ) : (
            <button
              onClick={signInWithGoogle}
              className="flex items-center gap-2 bg-white text-black hover:bg-gray-200 px-6 py-2 rounded-xl font-bold transition-all active:scale-95 shadow-[0_0_15px_rgba(255,255,255,0.2)]"
            >
              <LogIn className="w-5 h-5" />
              <span>دخول</span>
            </button>
          )}
        </div>
      </div>
    </nav>
  );
}
