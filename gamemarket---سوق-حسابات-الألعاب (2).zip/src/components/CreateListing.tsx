import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Upload, DollarSign, Trophy, Info, Camera } from 'lucide-react';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { GameCategory } from '../types';

interface CreateListingProps {
  onClose: () => void;
  onSuccess: () => void;
}

const CATEGORIES: GameCategory[] = ['Valorant', 'League of Legends', 'Steam', 'Battle.net', 'Epic Games', 'Other'];

export default function CreateListing({ onClose, onSuccess }: CreateListingProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    game: 'Valorant' as GameCategory,
    price: '',
    description: '',
    level: '',
    rank: '',
    image: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;

    setLoading(true);
    const path = 'accounts';
    try {
      await addDoc(collection(db, path), {
        ...formData,
        price: Number(formData.price),
        level: Number(formData.level),
        sellerId: auth.currentUser.uid,
        sellerName: auth.currentUser.displayName || 'لاعب مجهول',
        status: 'available',
        images: [formData.image || `https://picsum.photos/seed/${Math.random()}/800/600`],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      onSuccess();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-gray-900 border border-indigo-500/30 w-full max-w-2xl rounded-[2.5rem] overflow-hidden shadow-[0_0_50px_rgba(79,70,229,0.2)]"
        dir="rtl"
      >
        <div className="p-8 flex items-center justify-between border-b border-gray-800">
          <h2 className="text-2xl font-black text-white px-2">بيع حسابك الآن</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-800 rounded-full text-gray-400 transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6 overflow-y-auto max-h-[70vh]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-gray-400 text-sm font-bold mr-2">عنوان العرض</label>
              <input
                required
                type="text"
                placeholder="مثال: حساب لول برونز سكنات مميزة"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full bg-gray-800 border border-gray-700 rounded-2xl px-4 py-3 text-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all outline-none"
              />
            </div>

            <div className="space-y-2">
              <label className="text-gray-400 text-sm font-bold mr-2">اللعبة</label>
              <select
                value={formData.game}
                onChange={(e) => setFormData({ ...formData, game: e.target.value as GameCategory })}
                className="w-full bg-gray-800 border border-gray-700 rounded-2xl px-4 py-3 text-white focus:border-indigo-500 transition-all outline-none"
              >
                {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-gray-400 text-sm font-bold mr-2">السعر (بالدولار)</label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-indigo-500" />
                <input
                  required
                  type="number"
                  placeholder="0.00"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-2xl pl-10 pr-4 py-3 text-white focus:border-indigo-500 transition-all outline-none"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-gray-400 text-sm font-bold mr-2">الرتبة / المستوى</label>
              <div className="relative">
                <Trophy className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-indigo-500" />
                <input
                  type="text"
                  placeholder="مثال: Diamond II"
                  value={formData.rank}
                  onChange={(e) => setFormData({ ...formData, rank: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-2xl pl-10 pr-4 py-3 text-white focus:border-indigo-500 transition-all outline-none"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-gray-400 text-sm font-bold mr-2">رابط صورة الحساب (اختياري)</label>
            <div className="relative">
              <Camera className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-indigo-500" />
              <input
                type="url"
                placeholder="https://..."
                value={formData.image}
                onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                className="w-full bg-gray-800 border border-gray-700 rounded-2xl pl-10 pr-4 py-3 text-white focus:border-indigo-500 transition-all outline-none text-left"
                dir="ltr"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-gray-400 text-sm font-bold mr-2">وصف الحساب</label>
            <textarea
              rows={4}
              placeholder="اكتب تفاصيل الحساب، السكنات، الإنجازات..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full bg-gray-800 border border-gray-700 rounded-2xl px-4 py-3 text-white focus:border-indigo-500 transition-all outline-none resize-none"
            />
          </div>

          <button
            disabled={loading}
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xl rounded-2xl transition-all shadow-lg active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'جاري النشر...' : 'نشر الإعلان'}
          </button>
        </form>
      </motion.div>
    </motion.div>
  );
}
